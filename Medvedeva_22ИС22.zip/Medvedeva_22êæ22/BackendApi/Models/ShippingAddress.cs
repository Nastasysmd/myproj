﻿using System;
using System.Collections.Generic;

namespace BackendApi.Models
{
    public partial class ShippingAddress
    {
        public int Id { get; set; }
        public int? UserId { get; set; }
        public string? Country { get; set; }
        public string? City { get; set; }
        public string? Street { get; set; }
        public string? PostalCode { get; set; }

        public virtual User? User { get; set; }
    }
}
