﻿namespace DataAccess1
{
    public class Class1
    {

    }
}